const axios = require('axios')
const path = require('path')
const {app, BrowserWindow, ipcMain } = require("electron");
const { electron, enablePromiseAPIs } = require('process');
const fs = require('fs');
const { parse } = require('querystring');
const { request } = require('http');



//discord



//discord




var window;
function createWindow() {
    const win = new BrowserWindow({
        width:800, height:600,
        tittle: "Steam price item buyer",
        resizable: false,
        autoHideMenuBar: true,
        icon: __dirname + '/style/logo.png',
        
        webPreferences: {
            nodeIntegration: true
        }
    })
    win.loadURL(`file://${__dirname}/index.html`)
    
}





app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit()
    }
})

app.on('asynchronous-message', (event, arg) => {
    console.log(arg) // prints "ping"
    event.reply('asynchronous-reply', 'pong')
  })
  

app.on('synchronous-message', (event, arg) => {
    console.log(arg) // prints "ping"
    event.returnValue = 'pong'
})



//
//
//




ipcMain.on('check_data', (event, name_of_item, currency) => {
    console.log("got request check data of " + name_of_item + " from " + event)
    axios.get(`https://steamcommunity.com/market/priceoverview/?appid=730&market_hash_name=${name_of_item}&currency=${currency}`)
    .then((res) => {
        console.log(res.data) 
        event.sender.send("check_data_reply", res)
    })
    .catch((err) => {
        console.log("error check_data - " + err)
    })
    
})



//read saved items in saved_data.json
let saved_data_raw = fs.readFileSync("saved_data.json")
let saved_data = JSON.parse(saved_data_raw)
let string_finally_saved_data = `<div id='from-file'>`
for (i=0;i<saved_data.data.items_names.length;i++) {
    
    string_finally_saved_data = string_finally_saved_data + `<a><a style='font-weight:bold'><a style='font-weight:bold'>Name: </a>${unescape(saved_data["data"]["items_names"][i])} <a style='font-weight:bold'><br>Hashcode: </a> ${saved_data.data.items_names[i]}</a><br><br>` 
}

string_finally_saved_data = string_finally_saved_data + `</div>`
//document.getElementById('from-file').innerHTML = string_finally_saved_data


ipcMain.on('get-saved-data-items', (event) => {
    event.sender.send("get-saved-data-items-reply", string_finally_saved_data)
})

var request_buyitem = {
    "IInventoryService": {
        "appid":730
    }
    
}







app.on('ready', () => {
    window = createWindow()

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) {
            createWindow()
        }
    })
    
})