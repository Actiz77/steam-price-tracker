const { ipcRenderer, ipcMain } = require('electron')

ipcRenderer.on('app-version', (event, args) => {
    const appVersion = document.getElementById('app_version')
    console.log(`Node version is ${args}`)
    appVersion.innerHTML += args
})
let item_name_document;
let maximum_price_document = 0;
let price_option;
const audio = new Audio('https://cdn.discordapp.com/attachments/749422473652600942/841283936696533012/bell-ringing-05.mp3');


function only_numeric(string) {
    let transfered = ""

    for (i=0;i<=string.length;i++) {
        if (string[i] == "0" || string[i] == "1" || string[i] == "2" || string[i] == "3" || string[i] == "4" || string[i] == "5" || string[i] == "6" || string[i] == "7" || string[i] == "8" || string[i] == "9" || string[i] == "." || string[i] == ",") {
            transfered = transfered + string[i]
        }
    }
    
    return transfered
    
}

ipcRenderer.on('check_data_reply', (event, data) => {
    document.getElementById("output").innerHTML = `<div id='output'><a>Info for item <a style='font-weight:bold;'>${decodeURI(item_name_document)}</a></a>  <br>  <a>Lowest price: ${data.data.lowest_price}</a> <br> <a>Median price: ${data.data.median_price} <br> <a>Amount of items to sell: ${data.data.volume}</a> </a></div>`
    maximum_price_document = document.getElementById('min_price').value;
    price_option = document.getElementById("price_setting").value
    document.getElementById('item_image').innerHTML = `<div class="row" id='item_image'></div>`;
    console.log(maximum_price_document)
    
    if (price_option == "max") {
        if (maximum_price_document >= only_numeric(data.data.lowest_price) || maximum_price_document >= only_numeric(data.data.median_price)&& maximum_price_document != "") {
            audio.play();
            if (maximum_price_document >= only_numeric(data.data.lowest_price)) {
                ipcRenderer.send("price-alert", decodeURI(item_name_document),maximum_price_document, data.data.lowest_price)
            } else if (maximum_price_document >= only_numeric(data.data.median_price)){
                ipcRenderer.send("price-alert", decodeURI(item_name_document),maximum_price_document, data.data.lowest_price)
            }
    
        }
    } else if (price_option == "min") {
        if (maximum_price_document <= only_numeric(data.data.lowest_price) || maximum_price_document <= only_numeric(data.data.median_price)&& maximum_price_document != "") {
            audio.play();
            if (maximum_price_document >= only_numeric(data.data.lowest_price)) {
                ipcRenderer.send("price-alert", decodeURI(item_name_document),maximum_price_document, data.data.lowest_price)
            } else if (maximum_price_document >= only_numeric(data.data.median_price)){
                ipcRenderer.send("price-alert", decodeURI(item_name_document),maximum_price_document, data.data.lowest_price)
            }
    
        }
    }
    
    console.log(data)
})

ipcRenderer.send("get-saved-data-items")

ipcRenderer.on("get-saved-data-items-reply", (event, ready_string) => {

    document.getElementById('from-file').innerHTML = ready_string
})

setInterval(() => {
    item_name_document = document.getElementById("item_name").value; let output = document.getElementById("output"); maximum_price_document = document.getElementById('min_price').value
    if (item_name_document != "") {
        ipcRenderer.send("check_data", item_name_document, document.getElementById('currency').value)
    } else {
        output.innerHTML = "<div id='output'>Output: Waiting for item name</div>"
        
    }


    
        

}, 20000);

